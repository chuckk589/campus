(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-eef7eab8.js")
    );
  })().catch(console.error);

})();
