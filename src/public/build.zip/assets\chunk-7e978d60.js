const t="0.0.1",o="http:/localhost:3000";export{o as H,t as V};
